for ((i = 1; i <= 5; i++)); do svgexport ./svg/Part\ "$i".svg EasyEDA_part_"$i".png 10x ; done 
